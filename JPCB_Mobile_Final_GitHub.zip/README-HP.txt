JPCB MOBILE - BUILD APK DARI HP

Project ini adalah aplikasi Android WebView untuk membuka Web App JPCB Mobile:
https://script.google.com/macros/s/AKfycbwvJlMz3-5hrAFj20HZaiqaucZaEMbmUerEjue-LjzD83r_ZfoNTNfzC1ZLEeVG2Hg8Eg/exec?action=mobile

CARA DARI HP:
1. Login ke GitHub.
2. Buat repository baru, misalnya JPCB-Mobile.
3. Upload SELURUH isi project ini ke repository (bukan file ZIP-nya).
4. Buka tab Actions.
5. Pilih workflow "Build JPCB Mobile APK".
6. Tekan "Run workflow".
7. Tunggu sampai status berubah menjadi hijau (Success).
8. Buka run tersebut.
9. Scroll ke bagian Artifacts.
10. Download "JPCB-Mobile-debug".
11. Buka ZIP hasil download dan install app-debug.apk.

CATATAN:
- Project ini tidak mengubah Google Apps Script atau Spreadsheet JPCB.
- URL Web App sudah tertanam di MainActivity.kt.
- APK debug ditujukan untuk pemakaian/testing internal.
- Jika URL Web App berubah, MainActivity.kt harus diperbarui dan APK dibuat ulang.
