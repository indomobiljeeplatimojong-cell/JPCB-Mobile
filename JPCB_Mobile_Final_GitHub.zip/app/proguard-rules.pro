# JPCB Mobile - no custom ProGuard rules required.
